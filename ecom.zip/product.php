<?php   include "header.php"; ?>
      <section>
           <div class="product-container">
           <div class="column column-1  left-side">
            <div class="product-images">
                
            </div>
            <div class="prodcut_image ">
               <img class="product-img" src="img/product-1.jpeg">
                
            </div>
           </div>
           <div class="column column-2 right-side">
              <div class="product-title">
                  <h1> Apple Iphone X -128 GB </h1>
              </div>
              <div class="product-description">
               <h4 >Highlights</h4>
                <ul >
                    <li>8 GB RAM | 128 GB ROM |</li>
                    <li>13.97 cm (5.5 inch) Full HD Display</li>
                    <li>16MP + 20MP | 16MP Front Camera</li>
                    <li>3300 mAh Battery</li>
                </ul>
                 
              </div>
              <div class="comparison">
                <h3>Comparision</h3>
                <table>
                    <thead>
                        <th>Company</th>
                        <th>Price</th>
                        <th>Buy Now</th>
                    </thead>
                    <tbody>
                        <!-- <flipkart -->
                            <tr>
                        <td >
                           <div class="company-logo">
                            <img class="img-size" src="img/flipkart.jpg" style="height:100%;">
                        </div>
                        </td>
                        <td> <i class="fa-rupee-sign">26,000</i></td>
                        <td><button class="btn  button-sucess">Buy Now</button></td>
                        </tr>
                        <!-- <-amazon -->
                           <tr>
                           <td>

                           <div class="company-logo">
                            <img class="img-size" src="img/amazon.jpg" style="height:100%;">
                        </div>
                        </td>
                        <td> <i class="fa-rupee-sign">26,000</i></td>
                        <td><button class="btn  button-sucess">Buy Now</button></td>
                    </tr>
                    <!--  < ebay - -->
                    <tr>

                      <td>
                           <div class="company-logo">
                            <img class="img-size" src="img/ebay.jpg" style="height:100%;">
                        </div>
                        </td>
                        <td> <i class="fa-rupee-sign">26,000</i></td>
                        <td><button class="btn  button-sucess">Buy Now</button></td>
                     </tr>
                    </tbody>
                </table>
            
          </div>
           </div>
         </div>
         <div class="clear-float"></div>
            <div class="clear-float"></div>
        </section>
 <?php   include "footer.php"; ?>
