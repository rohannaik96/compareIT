
        <footer style="margin-top:20px;">
            <div class="footer">
                 <div class="container">
                  <div class="left-side">
                       demo
                  </div>
                  <div class="right-side">
                      copy@
                  </div>
                </div>
            </div>

        </footer>
        <script type="text/javascript">
          $( document ).ready(function() {

            $(".menu-icon").click(function(){
       $( "nav" ).toggleClass('active');
    });

       
    });
        </script>


    </body>
    </html>