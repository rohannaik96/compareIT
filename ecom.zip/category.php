<?php   include "header.php"; ?>
      <section>
            <div class="container section ">
                <div class="section-title">
            <h2 class="">Mobiles</h2>
                 </div>

            <div class="card-area flex">
                <div class="card product col-4 col-3 col-2 product-1">
                    <a href="product.php"> 
                    <img class=" img-size" src="img/cat-1.jpeg">
                    </a>
                </div>
                <div class="card col-4 col-3 col-2 product product-3">
                    <a href=""> 
                    <img class=" img-size" src="img/cat-2.jpg">
                </a>
                </div>
                <div class="card col-4 col-3 col-2 product product-3">
                    <a href=""> 
                    <img class=" img-size" src="img/cat3.jpg">
                </a>
                </div>
                <div class="card col-4 col-3 col-2 product product-4">
                    <a href=""> 
                    <img class=" img-size" src="img/cat4.jpg">
                </a>
                </div>
                
            </div>
            <div class="right-side mright-side">
                <a href=""> see more</a>
            </div>
            </div>
        </section>
    
    <?php   include "footer.php"; ?>