<?php   include "header.php"; ?>
    	<section>
    		<div class="slider">
    			<img class="img-slider" src="img/slider.jpeg" >
    			<div class="image-text">
    			<h1>DEmo bhbhbh hbhbhbh bhbhb bhbhvtfrc gvgyguihon hftftftf</h1>
    		</div>
    		</div>

    		<div class="clear-float"></div>
    	</section>
    	<section>
    		<div class="container section ">
    			<div class="section-title">
    		<h2 class="">Category</h2>
                 </div>

    		<div class="card-area flex">
    			<div class="card card-1">
                     <a href=""> 
    				<img class=" img-size" src="img/cat-1.jpeg">
                </a>
    			</div>
    			<div class="card card-2">
                     <a href=""> 
    				<img class=" img-size" src="img/cat-2.jpg">
                </a>
    			</div>
    			<div class="card card-3">
                     <a href=""> 
    				<img class=" img-size" src="img/cat1.jpg">
                </a>
    			</div>
    			
    		</div>
    		</div>
    	</section>
        <section>
            <div class="container section ">
                <div class="section-title">
            <h2 class="">Products</h2>
                 </div>

            <div class="card-area flex">
                <div class="card product col-4 col-3 col-2 product-1">
                    <a href=""> 
                    <img class=" img-size" src="img/cat-1.jpeg">
                    </a>
                </div>
                <div class="card col-4 col-3 col-2 product product-3">
                    <a href=""> 
                    <img class=" img-size" src="img/cat-2.jpg">
                </a>
                </div>
                <div class="card col-4 col-3 col-2 product product-3">
                    <a href=""> 
                    <img class=" img-size" src="img/cat3.jpg">
                </a>
                </div>
                <div class="card col-4 col-3 col-2 product product-4">
                    <a href=""> 
                    <img class=" img-size" src="img/cat4.jpg">
                </a>
                </div>
                
            </div>
            <div class="right-side mright-side">
                <a href=""> see more</a>
            </div>
            </div>
        </section>
     <?php   include "footer.php"; ?>