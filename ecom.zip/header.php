    <!DOCTYPE html>
    <html>
    <head>
    	  <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Ecomerce</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    	<link rel="stylesheet" type="text/css" href="css/style.css">
        <script  src="https://code.jquery.com/jquery-3.4.0.js"></script>
    </head>
    <body>
    	<header>
    		<div class="info-header container ">
    			<div class="mleft-side left-side">
    				<ul>
    					<li class="right-border" ><a href="">+91 9967077027</a></li>
    					<li class="right-border"><a href="">rohan@gmail.com</a></li>
    					
    				</ul>
    		

    			</div>
    			<div class="mright-side right-side" >
    				<ul>
    					<li class="right-border"><a href="">About Us</a></li>
    					<li class="right-border"><a href="">Sign up /Login</a></li>
    					<li ><a href="">Help</a></li>
    				</ul>
    			</div>
    			<div class="clear-float"></div>
    			</div>
    			<div class="horizontal-line"></div>
    		
    		<div class="container ">
    			<div class="logo left-side mleft-side">
    				<img class="img-responsive" src="img/logo.jpg" width="100%" height="100%">
    			</div>
                <div class="mright-side ">
                   <span class="fa fa-bars menu-icon"></span>
                </div>
    			<nav class="right-side main-nav" >
    				<ul>
    					<li><a href="index.php">Home</a></li>
    					<div class="dropdown">
                        <li><a  class="dropbtn">Category</a></li>
                        
  <div class="dropdown-content">
    <a href="category.php">Mobile</a>
    <a href="category.php">TV</a>
  </div>
</div>
    					<li><a href="">Contact</a></li>
    				</ul>
    			</nav>
    			
    		</div>
    		<div class="clear-float"></div>
    		<div class="clear-float"></div>
    	</header>
